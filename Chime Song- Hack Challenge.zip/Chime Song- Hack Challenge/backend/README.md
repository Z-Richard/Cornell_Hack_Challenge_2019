1. Make sure python3 is installed;
2. Go to /src folder, open up terminal, install dependencies using
    pip install -r requirements.txt
3. Run python app.py