from flask import Flask, request
import json
from db import db, Song, Comment

db_filename = 'app.db'
app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///%s' % db_filename
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ECHO'] = True

db.init_app(app)
with app.app_context():
    db.create_all()


@app.route('/api/songs/')
def get_all_songs():
    songs = Song.query.all()
    res = {'success': True, 'data': [s.serialize() for s in songs]}
    return json.dumps(res), 200


@app.route('/api/songs/', methods=['POST'])
def create_song():
    post_body = json.loads(request.data)
    song = Song(username=post_body.get('username', ''),
                title=post_body.get('title', ''))
    db.session.add(song)
    db.session.commit()
    return json.dumps({'success': True, 'data': song.serialize()}), 201


@app.route('/api/song/<int:song_id>/')
def get_song(song_id):
    song = Song.query.filter_by(id=song_id).first()
    if not song:
        return json.dumps({'success': False, 'error': 'Song not found!'}), 404
    return json.dumps({'success': True, 'data': song.serialize()}), 200


@app.route('/api/song/<int:song_id>/comments/', methods=['POST'])
def create_comment(song_id):
    song = Song.query.filter_by(id=song_id).first()
    if not song:
        return json.dumps({'success': False, 'error': 'Song not found!'}), 404
    post_body = json.loads(request.data)

    comment = Comment(
        username=post_body.get('username', ''),
        content=post_body.get('content', '')
    )
    song.comments.append(comment)
    db.session.add(comment)
    db.session.commit()

    return json.dumps({'success': True, 'data': comment.serialize()}), 200


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
