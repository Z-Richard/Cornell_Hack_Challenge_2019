//
//  TableViewCell.swift
//  cfr54_ql272_hackathon
//
//  Created by Charlie Ruan on 12/8/19.
//  Copyright © 2019 Charlie Ruan and Mike Liao. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    var dayLabel: UILabel!
    let padding: CGFloat = 8
    let fontSize: CGFloat = 25

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
           
        dayLabel = UILabel()
        dayLabel.font = UIFont.systemFont(ofSize: fontSize)
        dayLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(dayLabel)
        
        setupConstraints1()
}
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configure(for day: Day) {
        dayLabel.text = day.dayName
    }
    
    func setupConstraints1(){
    NSLayoutConstraint.activate([
        dayLabel.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
        dayLabel.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
    ])

}
}
