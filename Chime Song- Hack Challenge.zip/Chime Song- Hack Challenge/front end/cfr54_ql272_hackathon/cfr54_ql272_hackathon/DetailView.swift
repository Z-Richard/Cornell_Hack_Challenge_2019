//
//  DetailView.swift
//  cfr54_ql272_hackathon
//
//  Created by Charlie Ruan on 12/8/19.
//  Copyright © 2019 Charlie Ruan and Mike Liao. All rights reserved.
//

import UIKit

class DetailView: UIViewController {
    
    var timeLabel: UILabel!
    var timeTextField: UITextField!
    var songLabel: UILabel!
    var songTextField: UITextField!
    var reasonLabel: UILabel!
    var reasonTextView: UITextView!
    var uploadButton: UIButton!
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init() {
        super.init(nibName: nil, bundle: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        title = "Edit Your Request"
        
        timeLabel = UILabel()
        timeLabel.translatesAutoresizingMaskIntoConstraints = false
        timeLabel.text = "Time Requesting: "
        timeLabel.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        view.addSubview(timeLabel)
        
        timeTextField = UITextField()
        timeTextField.translatesAutoresizingMaskIntoConstraints = false
        timeTextField.borderStyle = .roundedRect
        timeTextField.backgroundColor = .white
        timeTextField.clearsOnBeginEditing = true
        timeTextField.text = " ex: 5:30pm"
        timeTextField.clearsOnBeginEditing = true
        view.addSubview(timeTextField)
        
        songLabel = UILabel()
        songLabel.translatesAutoresizingMaskIntoConstraints = false
        songLabel.text = "Song Name: "
        songLabel.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        view.addSubview(songLabel)
        
        songTextField = UITextField()
        songTextField.translatesAutoresizingMaskIntoConstraints = false
        songTextField.borderStyle = .roundedRect
        songTextField.backgroundColor = .white
        songTextField.clearsOnBeginEditing = true
        view.addSubview(songTextField)
        
        reasonLabel = UILabel()
        reasonLabel.translatesAutoresizingMaskIntoConstraints = false
        reasonLabel.text = "Please explain the story behind this song: "
        reasonLabel.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        view.addSubview(reasonLabel)
        
        reasonTextView = UITextView()
        reasonTextView.translatesAutoresizingMaskIntoConstraints = false
        reasonTextView.layer.borderColor = UIColor.systemGray.cgColor
        reasonTextView.layer.borderWidth = 1
        reasonTextView.isEditable = true
        reasonTextView.backgroundColor = .white
        view.addSubview(reasonTextView)
        
        let uploadButton = UIBarButtonItem(title: "Upload", style: .plain, target: self, action: #selector(saveFunction))
        self.navigationItem.rightBarButtonItem = uploadButton
        
        setupConstraints()
    }
    
    @objc func saveFunction() {
        if let time = timeTextField.text, time != "" {
            //upload time to API, but we do not know how to :(
        }
        if let song = songTextField.text, song != "" {
            //upload song to API, but we do not know how to :(
        }
        if let reason = reasonTextView.text, reason != ""{
            //upload reaosn to API, but we do not know how to :(
        }
        
        self.navigationController?.popViewController(animated: true) != nil
    }
    
    func setupConstraints() {
    // textField constraints
    
    NSLayoutConstraint.activate([
        timeLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 30),
        timeLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10)
    ])
        
    NSLayoutConstraint.activate([
        timeTextField.topAnchor.constraint(equalTo: timeLabel.topAnchor),
        timeTextField.leadingAnchor.constraint(equalTo: timeLabel.trailingAnchor, constant: 10)
    ])
    
    NSLayoutConstraint.activate([
        songLabel.topAnchor.constraint(equalTo: timeLabel.bottomAnchor, constant: 15),
        songLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10)
    ])
    
    NSLayoutConstraint.activate([
        songTextField.topAnchor.constraint(equalTo: songLabel.topAnchor),
        songTextField.leadingAnchor.constraint(equalTo: timeTextField.leadingAnchor),
        songTextField.trailingAnchor.constraint(equalTo: timeTextField.trailingAnchor)
    ])
    
    NSLayoutConstraint.activate([
        reasonLabel.topAnchor.constraint(equalTo: songLabel.bottomAnchor, constant: 15),
        reasonLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10)
    ])
    
    NSLayoutConstraint.activate([
        reasonTextView.topAnchor.constraint(equalTo: reasonLabel.bottomAnchor, constant: 15),
        reasonTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
        reasonTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
        reasonTextView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -10)
    ])
    
    }
    
}
