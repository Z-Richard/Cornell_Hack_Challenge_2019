//
//  ViewController.swift
//  cfr54_ql272_hackathon
//
//  Created by Charlie Ruan on 12/8/19.
//  Copyright © 2019 Charlie Ruan and Mike Liao. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var tableView: UITableView!
    var days: [Day]!
    
    let reuseIdentifier = "songCellReuse"
    let cellHeight: CGFloat = 130
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Chime Song Request"
        view.backgroundColor = .white
        
        let monday = Day(dayName: "Monday")
        let tuesday = Day(dayName: "Tuesday")
        let wednesday = Day(dayName: "Wednesday")
        let thursday = Day(dayName: "Thursday")
        let friday = Day(dayName: "Friday")
        let saturday = Day(dayName: "Saturday")
        let sunday = Day(dayName: "Sunday")
        
        days = [monday, tuesday, wednesday, thursday, friday, saturday, sunday]
        
        tableView = UITableView()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.register(TableViewCell.self, forCellReuseIdentifier: reuseIdentifier)
        view.addSubview(tableView)
        
        setupConstraints()
    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
    }
    

}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return days.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! TableViewCell
        let day = days[indexPath.row]
        cell.configure(for: day)
        cell.selectionStyle = .none
        return cell
    }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellHeight
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let viewController = DetailView()
            navigationController?.pushViewController(viewController, animated: true)
            }
    }



