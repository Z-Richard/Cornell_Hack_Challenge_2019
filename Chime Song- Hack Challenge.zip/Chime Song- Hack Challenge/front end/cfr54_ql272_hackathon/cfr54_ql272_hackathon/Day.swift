//
//  File.swift
//  cfr54_ql272_hackathon
//
//  Created by Charlie Ruan on 12/8/19.
//  Copyright © 2019 Charlie Ruan and Mike Liao. All rights reserved.
//

import Foundation

class Day {
    var dayName: String
    
    init(dayName: String) {
        self.dayName = dayName
    }
}

